/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.a3_testes;

/**
 *
 * @author User
 */
public class A3_Testes {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
